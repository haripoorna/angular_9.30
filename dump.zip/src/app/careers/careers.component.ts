import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-careers',
  templateUrl: './careers.component.html',
  styleUrls: ['./careers.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CareersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
